# Second Screen PiP

**Играйте за двоих с одного компьютера и одного Steam-аккаунта: вторая копия R.E.P.O. показывается маленьким окошком прямо в первой.**

*Play both sides of a lobby on one PC with a single Steam account: the second R.E.P.O. window is shown as a picture-in-picture box inside the first one.*

## Возможности / Features
- Окошко «Игрок 2» в окне хоста с живой картинкой второй копии игры (F8 - показать/скрыть, перетаскивается мышью).
- **F4** переключает на другое окно игры (из любого из двух окон).
- **F2** запускает вторую копию `REPO.exe` (клавиша настраивается).
- Встроенный локальный мультиплеер: вторая копия заходит в вашу комнату под другим Steam ID. Отдельный мод LocalMultiplayer **не нужен**.
- Окно не «засыпает» в фоне (`runInBackground`).
- Press **F2** to launch a second game copy; it joins your lobby with a spoofed Steam ID. PiP toggles with **F8**.

## Что нужно / Requirements
1. **BepInEx 5** (BepInExPack для R.E.P.O.).
2. Два бесплатных приложения **Photon** (оплата не нужна):
   1. Зайдите на https://dashboard.photonengine.com и войдите / зарегистрируйтесь.
   2. Создайте приложение с SDK **Pun** - скопируйте его App ID.
   3. Создайте приложение с SDK **Voice** - скопируйте его App ID.
3. В игре: **Настройки → Графика → Оконный режим** (чтобы видеть оба окна).

## Настройка / Setup
1. Один раз запустите игру, чтобы создался конфиг `BepInEx\config\local.secondscreenpip.cfg`.
2. Откройте его и впишите:
   - `AppIdRealtime` = App ID приложения **Pun**
   - `AppIdVoice` = App ID приложения **Voice**
3. (Если раньше стоял LocalMultiplayer, значения подхватятся из его `global.cfg` сами; старую DLL LocalMultiplayer из `plugins` удалите.)

## Как играть / Usage
1. Запустите игру (хост) и создайте **приватную игру** (комната должна быть создана).
2. Нажмите **F2** - откроется вторая копия игры.
3. Во второй копии нажмите **«Присоединиться»** - она зайдёт в вашу комнату.
4. В окне хоста появится окошко «Игрок 2». **Не сворачивайте** вторую копию: свёрнутое окно Unity не рисует кадры, и в окошке будет «Нет сигнала».

## Настройки конфига / Config
`BepInEx\config\local.secondscreenpip.cfg`
| Параметр | Что делает |
|---|---|
| `Role` | Auto / Host / SecondWindow. Auto: первое окно - хост, остальные передают картинку |
| `ToggleKey` (F8), `LaunchKey` (F2), `SwitchKey` (F4) | Клавиши: показать/скрыть окошко, запустить вторую копию, переключить окно |
| `Title`, `Width`, `X`, `Y` | Заголовок, размер и позиция окошка |
| `Capture.Width`, `Fps`, `JpgQuality` | Чёткость и частота кадров |
| `FlipVertical` | Если картинка вверх ногами - переключите |
| `AppIdRealtime`, `AppIdVoice` | Ваши Photon App ID |
| `LaunchPassArgs` | Передавать аргументы запуска второй копии (обычно выключено) |

## Как это работает / How it works
Второе окно раз в долю секунды снимает свой экран, кодирует в JPEG и кладёт в `%TEMP%\RepoSecondScreenPip\frame.jpg`; хост читает файл и рисует его в окошке. Сеть для картинки не используется.

## Решение проблем / Troubleshooting
- **«Нет сигнала»** - вторая копия свёрнута или не запущена, либо в ней не загрузился BepInEx (нет метки `[MODDED]` в меню).
- **«UserId already joined»** - во второй копии не работает подмена аккаунта: проверьте Photon App ID и что старый LocalMultiplayer удалён.
- **Не могу присоединиться** - сначала создайте комнату в первом окне, потом жмите «Присоединиться» во втором.
- Логи: `BepInEx\LogOutput.log`, ищите строки `LocalMp` и `Second Screen PiP`.

## Благодарности / Credits
Встроенный локальный мультиплеер основан на идее и коде **LocalMultiplayer** от Zehs (MIT): https://github.com/ZehsTeam/REPO-LocalMultiplayer

## Лицензия / License
MIT.
